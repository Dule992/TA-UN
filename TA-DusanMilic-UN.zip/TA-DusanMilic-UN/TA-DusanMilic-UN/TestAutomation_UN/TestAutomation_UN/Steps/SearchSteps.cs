﻿using BoDi;
using FluentAssertions;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
using TestAutomation_UN.Pages;

namespace TestAutomation_UN.Steps
{
    [Binding]
    [Scope(Tag = "search")]
    public class SearchSteps
    {
        private readonly IWebDriver _webDriver;
        private readonly ScenarioContext _scenarioContext;
        private SearchPage _searchPage;


        public SearchSteps(IWebDriver webDriver, ScenarioContext scenarioContext, SearchPage searchPage)
        {
            _webDriver = webDriver;
            _scenarioContext = scenarioContext;
            _searchPage = searchPage;
        }

        [Given(@"User opens the home page on the unterm website")]
        public void GivenUserOpensTheHomePageOnTheUntermWebsite()
        {
            _webDriver.Navigate().GoToUrl("https://unterm.un.org/unterm2/en");
            _searchPage.isSearchBarDisplayed().Should().BeTrue();
        }

        [When(@"User enters ""(.*)"" keyword in the search bar")]
        public void WhenUserEntersKeywordInTheSearchBar(string keyword)
        {
            _searchPage.EnterKeyword(keyword);
        }

        [When(@"User clicks on the search button")]
        public void WhenUserClicksOnTheSearchButton()
        {
            _searchPage.ClickOnSearchButton();
        }

        [Then(@"All records which contains ""(.*)"" keyword should be presented")]
        public void ThenAllRecordsWhichContainsKeywordShouldBePresented(string keyword)
        {
            var recordItemText = _searchPage.CheckRecordItemsHasText(keyword);
            recordItemText.Should().BeTrue();
        }

        [Then(@"No Results Found for ""(.*)"" message should be presented")]
        public void ThenNoResultsFoundForMessageShouldBePresented(string keyword)
        {
            var noResultsFoundMessageBox = _searchPage.GetNoResultsFoundMessageBox();
            noResultsFoundMessageBox.Should().BeTrue();

            if (noResultsFoundMessageBox)
            {
                var noResultsFoundMessageKeyword = _searchPage.GetNoResultsFoundMessageKeyword(keyword);
                noResultsFoundMessageKeyword.Should().BeTrue();
            }
        }
    }
}
