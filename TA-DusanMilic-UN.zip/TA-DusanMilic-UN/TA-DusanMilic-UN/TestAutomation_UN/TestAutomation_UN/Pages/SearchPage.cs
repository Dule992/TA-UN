﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace TestAutomation_UN.Pages
{
    public class SearchPage
    {
        private IWebDriver _webDriver;
        private IWait<IWebDriver> _webDriverWait;

        public SearchPage(IWebDriver webDriver, IWait<IWebDriver> webDriverWait)
        {
            _webDriver = webDriver;
            _webDriverWait = webDriverWait;
        }

        #region Elements       

        private IWebElement searchBar => _webDriver.FindElement(By.Id("autoComplete"));
        private IWebElement searchButton => _webDriver.FindElement(By.CssSelector(".btn.search-button"));
        private IWebElement resultsTable => _webDriver.FindElement(By.Id("results-table"));
        private IList<IWebElement> recordItems => _webDriver.FindElements(By.CssSelector(".search-result em"));
        private IWebElement noResultMessageBox => _webDriver.FindElement(By.CssSelector(".no-data-message"));
        private IWebElement noResultMessage(string keyword) => _webDriver.FindElement(By.CssSelector($"em[title='{keyword}']"));


        #endregion

        #region Methods

        public bool isSearchBarDisplayed()
        {
            return searchBar.Displayed;
        }

        public void EnterKeyword(string keyword)
        {
            searchBar.SendKeys(keyword);
        }

        public void ClickOnSearchButton()
        {
            searchButton.Click();
        }

        public bool CheckRecordItemsHasText(string keyword)
        {
            _webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            return recordItems.Any(item => item.Text.Contains(keyword));
        }

        public bool GetNoResultsFoundMessageBox()
        {
            _webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            return noResultMessageBox.Displayed;
        }

        public bool GetNoResultsFoundMessageKeyword(string keyword)
        {
            return noResultMessage(keyword).Displayed;
        }
        #endregion
    }
}
