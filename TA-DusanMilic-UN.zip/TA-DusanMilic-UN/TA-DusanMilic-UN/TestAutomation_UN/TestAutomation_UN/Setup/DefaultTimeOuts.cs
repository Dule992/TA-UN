﻿namespace TestAutomation_UN.Setup
{
    public class DefaultTimeOuts
    {   
        //timeout constants
        public const int SHORT_TIMEOUT = 10;
        public const int DEFAULT_TIMEOUT = 30;
        public const int SAVING_TIMEOUT = 70;
        public const int OPENING_TIMEOUT = 60;
        public const int MEDIUM_TIMEOUT = 30;
        public const int PAGE_LOAD_TIMEOUT = 90;
        public const int DEFAULT_POLLING_INTERVAL = 1;
    }
}
