﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace TestAutomation_UN.Setup
{
    public class BaseSetup
    {
        private IWebDriver _webDriver;

        public BaseSetup()
        {
            _webDriver = new ChromeDriver();
        }

        public void Dispose()
        {
            if (_webDriver != null)
            {
                _webDriver.Quit();
                _webDriver = null;
            }
        }
    }
}
