﻿using BoDi;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Drawing;
using System.IO;
using TechTalk.SpecFlow;

namespace TestAutomation_UN.Setup
{
    [Binding]
    public class BaseSetup: IDisposable
    {
        private IWebDriver _webDriver;
        private IWait<IWebDriver> _webDriverWait;
        private IObjectContainer _objectContainer;
        private readonly ScenarioContext _scenarioContext;
        

        public BaseSetup(IObjectContainer objectContainer, ScenarioContext scenarioContext)
        {
            _objectContainer = objectContainer;
            _scenarioContext = scenarioContext;
        }

        [BeforeScenario]
        public void GetWebDriver()
        {
            ChromeOptions options_chrome = new ChromeOptions();
            options_chrome.AddArgument("--verbose");
            options_chrome.AddArgument("--no-sandbox");
            options_chrome.AddArgument("−−mute−audio");
            options_chrome.AddArgument("--disable-gpu");
            options_chrome.AddArgument("--disable-infobars");
            options_chrome.AddArgument("--disable-blink-features=AutomationControlled");
            options_chrome.AddArgument("--disable-extensions");
            options_chrome.AddArgument("--disable-popup-blocking");
            options_chrome.AddArgument("--disable-notifications");
            options_chrome.PageLoadStrategy = PageLoadStrategy.Eager;
            _webDriver = new ChromeDriver(PathToDirectory(), options_chrome, TimeSpan.FromSeconds(180));

            _webDriver.Manage().Window.Size = new Size(1920, 1080);

            //adding to container
            _objectContainer.RegisterInstanceAs(_webDriver, typeof(IWebDriver));
            _webDriverWait = new WebDriverWait(_webDriver, TimeSpan.FromSeconds(DefaultTimeOuts.DEFAULT_TIMEOUT));
            _objectContainer.RegisterInstanceAs(_webDriverWait, typeof(IWait<IWebDriver>));
        }

        public string PathToDirectory()
        {
            var path = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            return path;
        }

        [AfterScenario]
        public void Dispose()
        {
            if (_webDriver != null)
            {
                _webDriver.Quit();
                _webDriver = null;
            }
        }
    }
}
