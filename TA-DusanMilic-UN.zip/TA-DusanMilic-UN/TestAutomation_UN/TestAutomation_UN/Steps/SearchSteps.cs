﻿using FluentAssertions;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
using TestAutomation_UN.Pages;

namespace TestAutomation_UN.Steps
{
    [Binding]
    [Scope(Tag = "search")]
    public class SearchSteps
    {
        private readonly IWebDriver _webDriver;
        private readonly SearchPage _searchPage;
        private readonly ScenarioContext _scenarioContext;


        public SearchSteps(IWebDriver webDriver, ScenarioContext scenarioContext)
        {
            _webDriver = webDriver;
            _searchPage = new SearchPage(_webDriver);
            _scenarioContext = scenarioContext;
        }

        [Given(@"Given User opens the home page on the unterm website")]
        public void GivenUserOpensTheHomePageOnTheUntermWebsite()
        {
            _webDriver.Navigate().GoToUrl("https://www.unterm.com/");
        }

        [When(@"User enters ""(.*)"" keyword in the search bar")]
        public void WhenUserEntersKeywordInTheSearchBar(string keyword)
        {
            _searchPage.EnterKeyword(keyword);
        }

        [When(@"User clicks on the search button")]
        public void WhenUserClicksOnTheSearchButton()
        {
            _searchPage.ClickOnSearchButton();
        }

        [Then(@"All records which contains ""(.*)"" keyword should be presented")]
        public void ThenAllRecordsWhichContainsKeywordShouldBePresented(string keyword)
        {
            var recordItemText = _searchPage.GetRecordItemText();
            recordItemText.Should().Contain(keyword);
        }
    }
}
