﻿using OpenQA.Selenium;

namespace TestAutomation_UN.Pages
{
    public class SearchPage
    {
       private IWebDriver _webDriver;

        public SearchPage(IWebDriver webDriver)
        {
            _webDriver = webDriver;
        }

        #region Elements       

        private IWebElement searchBar => _webDriver.FindElement(By.Id("autoComplete"));
        private IWebElement searchButton => _webDriver.FindElement(By.CssSelector("btn.search-button"));
        private IWebElement recordItem => _webDriver.FindElement(By.TagName("em"));

        #endregion

        #region Methods

        public void EnterKeyword(string keyword)
        {
           searchBar.SendKeys(keyword);
        }

        public void ClickOnSearchButton()
        {
            searchButton.Click();
        }

        public string GetRecordItemText()
        {
            return recordItem.Text;
        }
        #endregion
    }
}
